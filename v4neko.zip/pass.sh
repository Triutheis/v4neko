#!/bin/bash

# Định nghĩa khóa hợp lệ cùng với thời gian hết hạn
declare -A keys_with_expiration
keys_with_expiration=(
    ["TThai_mdugskfrhc"]="2024-10-10"
)

# Yêu cầu người dùng nhập key
echo "Nhập key để khởi động mạng"
read user_key

# Lấy ngày hiện tại
current_date=$(date +%Y-%m-%d)

# Kiểm tra xem key có hợp lệ và còn hiệu lực không
if [[ -n "${keys_with_expiration[$user_key]}" ]]; then
    expiration_date="${keys_with_expiration[$user_key]}"
    
    if [[ "$current_date" < "$expiration_date" ]]; then
        echo "Key hợp lệ và còn hiệu lực. Truy cập được phép!"
        clear && echo "Đang khởi động..." && tun
    else
        echo "Key hợp lệ nhưng đã hết hạn. Truy cập bị từ chối!"
    fi
else
    echo "Key không hợp lệ. Truy cập bị từ chối!"
fi