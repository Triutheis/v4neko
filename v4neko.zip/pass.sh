#!/bin/bash

# File chứa danh sách khóa và ngày hết hạn
key_file="keys.txt"

# Yêu cầu người dùng nhập key
echo "Nhập khóa của bạn:"
read user_key

# Lấy ngày hiện tại
current_date=$(date +%Y-%m-%d)

# Kiểm tra xem key có hợp lệ và còn hiệu lực không
if grep -q "^$user_key:" "$key_file"; then
    expiration_date=$(grep "^$user_key:" "$key_file" | cut -d':' -f2)
    
    # Chuyển đổi định dạng ngày
    IFS='-' read -r year month day <<< "$expiration_date"
    formatted_expiration_date="$day-$month-$year"

    if [[ "$current_date" < "$formatted_expiration_date" ]]; then
        echo "Khóa hợp lệ và còn hiệu lực. Truy cập được phép!"
        clear && echo "Đang khởi động..." && chay
    else
        echo "Khóa hợp lệ nhưng đã hết hạn. Truy cập bị từ chối!"
    fi
else
    echo "Khóa không hợp lệ. Truy cập bị từ chối!"
fi