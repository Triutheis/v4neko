#!/bin/bash

# File chứa danh sách khóa và ngày hết hạn
key_file="keys.txt"
admin_password_file="admin_password.txt"

# Kiểm tra nếu file không tồn tại, tạo file mới
if [[ ! -f $key_file ]]; then
    touch $key_file
fi

# Kiểm tra nếu file mật khẩu không tồn tại, yêu cầu tạo mật khẩu
if [[ ! -f $admin_password_file ]]; then
    echo "Tạo mật khẩu cho admin:"
    read -s admin_password
    echo "$admin_password" | openssl enc -aes-256-cbc -a -salt -pass pass:your_secret_key > $admin_password_file
    echo "Mật khẩu đã được tạo."
    exit
fi

# Đọc mật khẩu đã mã hóa
stored_password=$(openssl enc -aes-256-cbc -d -a -pass pass:your_secret_key -in $admin_password_file)

# Yêu cầu nhập mật khẩu admin
echo "Nhập mật khẩu admin:"
read -s input_password

# Kiểm tra mật khẩu
if [[ "$input_password" != "$stored_password" ]]; then
    echo "Mật khẩu không đúng. Truy cập bị từ chối!"
    exit
fi

# Hàm thêm khóa
add_key() {
    echo "Nhập khóa mới:"
    read new_key
    echo "Nhập ngày hết hạn (DD-MM-YYYY):"
    read expiration_date
    IFS='-' read -r day month year <<< "$expiration_date"
    formatted_date="$year-$month-$day"
    echo "$new_key:$formatted_date" >> $key_file
    echo "Khóa đã được thêm."
}

# Hàm xóa khóa
delete_key() {
    echo "Nhập khóa cần xóa:"
    read key_to_delete
    sed -i "/^$key_to_delete:/d" $key_file
    echo "Khóa đã được xóa (nếu tồn tại)."
}

# Menu lựa chọn
while true; do
    echo "Chọn một tùy chọn:"
    echo "1. Thêm khóa"
    echo "2. Xóa khóa"
    echo "3. Hiển thị tất cả khóa"
    echo "4. Thoát"
    read choice

    case $choice in
        1) add_key ;;
        2) delete_key ;;
        3) cat $key_file ;;
        4) exit ;;
        *) echo "Lựa chọn không hợp lệ." ;;
    esac
done